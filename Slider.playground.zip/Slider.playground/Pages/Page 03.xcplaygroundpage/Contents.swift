//#-hidden-code
import PlaygroundSupport
let Scene = Singleton.instance.Scene
PlaygroundSupport.PlaygroundPage.current.liveView = Singleton.instance.View
Scene.setState(Drawing03(Scene: Scene))
//#-code-completion(everything, hide)
//#-end-hidden-code
/*:
 Ring ring! Wake up Mikie!
 
 ![Alarm](alarm.png)
 
 Time to go to school!
*/
